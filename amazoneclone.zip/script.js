
        // // Function to move pictures
        // function movePictures() {
        //     const pictures = document.querySelectorAll('.box-img');

        //     pictures.forEach((picture) => {
        //         // Generate a random position for the picture
        //         const xPos = Math.floor(Math.random() * window.innerWidth);
        //         const yPos = Math.floor(Math.random() * window.innerHeight);

        //         // Set the position of the picture
        //         picture.style.left = `${xPos}px`;
        //         picture.style.top = `${yPos}px`;
        //     });
        // }

        // // Move the pictures initially
        // movePictures();

        // // Move the pictures when the window is resized
        // window.addEventListener('resize', movePictures);
    